import { Component } from '@angular/core';
import { NgForm , FormGroup, FormBuilder,Validators} from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent
 {
  Cities : string [] =  ['London','New York','Boston','Pune','Mumbai'];

  nForm:FormGroup;
  name: string= '';
  sdate :Date;
  edate :Date;
  post: any;

  constructor(private fb : FormBuilder)
  {
    this.nForm = fb.group(
        {
      'cname' : [null],
      'sdate' : [null],
      'edate' : [null],
      'validate': ''
        }
    )
  }
 
  addPost(post)
  {
    this.name=post.cname;
    this.sdate=post.sdate;
    this.edate=post.edate;
  }
  display(){
    console.log(this.name);
    console.log(this.sdate);
    console.log(this.edate);
  }
}
